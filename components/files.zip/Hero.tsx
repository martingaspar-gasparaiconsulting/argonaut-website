"use client";

import { useEffect, useRef, useState } from "react";

export default function Hero() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [videoLoaded, setVideoLoaded] = useState(false);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.play().catch(() => {});
    }
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-[#0A1628]">
      {/* Video Background */}
      <div className="absolute inset-0 z-0">
        <video
          ref={videoRef}
          autoPlay
          loop
          muted
          playsInline
          onCanPlay={() => setVideoLoaded(true)}
          className={`w-full h-full object-cover transition-opacity duration-1000 ${
            videoLoaded ? "opacity-40" : "opacity-0"
          }`}
          // HIER dein Video einfügen — z.B. /videos/hero-boebling.mp4
          // Empfehlung: Pexels-Video „Mittelstand Arbeit" oder eigenes Drone-Video Böblingen
          src="/videos/hero.mp4"
          poster="/images/hero-poster.jpg"
        />
        {/* Overlay-Gradient */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#0A1628]/60 via-[#0A1628]/30 to-[#0A1628]/80" />
      </div>

      {/* Goldene Akzentlinie oben */}
      <div className="absolute top-0 left-0 right-0 h-[3px] bg-[#C9A84C] z-20" />

      {/* Hero Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 bg-[#C9A84C]/10 border border-[#C9A84C]/30 rounded-full px-5 py-2 mb-8">
          <span className="text-[#C9A84C] text-sm font-medium tracking-widest uppercase">
            ⚔️ KI-Automatisierung für den Mittelstand
          </span>
        </div>

        {/* Hauptheadline */}
        <h1 className="text-5xl md:text-7xl font-bold text-white leading-tight mb-6">
          Andere kämpfen{" "}
          <span className="text-[#C9A84C]">alleine.</span>
          <br />
          Helden haben{" "}
          <span className="relative inline-block">
            <span className="text-[#C9A84C]">Argonaut.</span>
            <span className="absolute -bottom-1 left-0 right-0 h-[2px] bg-[#C9A84C]/50" />
          </span>
        </h1>

        {/* Subline */}
        <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto mb-4 leading-relaxed">
          7 KI-Agenten. Eine Crew. Vollautomatisiert.
        </p>
        <p className="text-lg text-gray-400 max-w-2xl mx-auto mb-12">
          Für Unternehmer in Böblingen, Stuttgart und der Region — die endlich
          aufhören wollen, alles alleine zu tragen.
        </p>

        {/* CTAs */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <a
            href="#kontakt"
            className="group relative inline-flex items-center gap-3 bg-[#C9A84C] hover:bg-[#b8973d] text-[#0A1628] font-bold text-lg px-8 py-4 rounded-lg transition-all duration-200 hover:scale-105 shadow-lg shadow-[#C9A84C]/20"
          >
            <span>⚔️</span>
            <span>Starte deine Mission</span>
            <span className="group-hover:translate-x-1 transition-transform duration-200">
              →
            </span>
          </a>
          <a
            href="#agenten"
            className="inline-flex items-center gap-3 border border-white/20 hover:border-[#C9A84C]/50 text-white hover:text-[#C9A84C] font-medium text-lg px-8 py-4 rounded-lg transition-all duration-200 backdrop-blur-sm"
          >
            <span>Die 7 Agenten kennenlernen</span>
            <span>↓</span>
          </a>
        </div>

        {/* Social Proof */}
        <div className="mt-16 flex flex-col sm:flex-row items-center justify-center gap-8 text-gray-400">
          <div className="flex items-center gap-2">
            <span className="text-[#C9A84C] font-bold text-2xl">7</span>
            <span className="text-sm">KI-Agenten<br />rund um die Uhr</span>
          </div>
          <div className="hidden sm:block w-px h-10 bg-white/10" />
          <div className="flex items-center gap-2">
            <span className="text-[#C9A84C] font-bold text-2xl">14,70€</span>
            <span className="text-sm">pro Tag für<br />die komplette Crew</span>
          </div>
          <div className="hidden sm:block w-px h-10 bg-white/10" />
          <div className="flex items-center gap-2">
            <span className="text-[#C9A84C] font-bold text-2xl">90 Min.</span>
            <span className="text-sm">bis deine Crew<br />arbeitet</span>
          </div>
        </div>
      </div>

      {/* Scroll-Indikator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2 text-gray-500">
        <span className="text-xs tracking-widest uppercase">Scroll</span>
        <div className="w-px h-12 bg-gradient-to-b from-gray-500 to-transparent animate-pulse" />
      </div>
    </section>
  );
}
